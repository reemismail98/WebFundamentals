var arr=[6,3,5,1,2,4];
var sum=0;
for(var i=0;i<arr.length;i++){
sum+=arr[i];
console.log("num "+arr[i]);
console.log("sum "+sum);
}

var arr=[6,3,5,1,2,4];
for(var i=0;i<arr.length;i++){
arr[i]*=i;
}
console.log(arr);