var odd=0;
for(var i = 1; i <= 20; i++){
    if(i % 2 !== 0){
        odd=i;
            console.log(odd);

    }
}

var sum=0;
for(var i=1;i<=5;i++){
sum+=i;
console.log("num="+ i);
console.log("sum="+sum);
}